use colored::*;
use goblin::Object;
use std::fs;
use std::io::{self, Write};

/// Tính toán Shannon Entropy (0.0 -> 8.0 bits/byte) của một vùng dữ liệu nhị phân
/// giúp nhận biết vùng code bình thường hay vùng dữ liệu đã bị nén (packed) / mã hóa.
fn calculate_entropy(data: &[u8]) -> f64 {
    if data.is_empty() {
        return 0.0;
    }
    let mut counts = [0usize; 256];
    for &b in data {
        counts[b as usize] += 1;
    }
    let len = data.len() as f64;
    let mut entropy = 0.0;
    for &c in &counts {
        if c > 0 {
            let p = (c as f64) / len;
            entropy -= p * p.log2();
        }
    }
    entropy
}

pub fn run() {
    println!("{}", "--- MODULE 2: EXECUTABLE BINARY FORMAT & ENTROPY ANALYZER ---".bold().bright_green());
    print!("{}", "Nhập đường dẫn file thực thi (Enter để tự mổ xẻ chính file đang chạy): ".cyan());
    let _ = io::stdout().flush();

    let mut path_in = String::new();
    let _ = io::stdin().read_line(&mut path_in);
    let target_path = if path_in.trim().is_empty() {
        std::env::current_exe()
            .map(|p| p.to_string_lossy().to_string())
            .unwrap_or_else(|_| "/bin/ls".to_string())
    } else {
        path_in.trim().to_string()
    };

    let buffer = match fs::read(&target_path) {
        Ok(b) => b,
        Err(e) => {
            println!("{} Không đọc được file '{}': {}", "[!]".red(), target_path, e);
            return;
        }
    };

    let whole_entropy = calculate_entropy(&buffer);
    println!(
        "\n{} File: {} | Kích thước: {} bytes | Entropy tổng: {:.3} bits/byte",
        "[+]".bright_green(),
        target_path.bold().white(),
        buffer.len(),
        whole_entropy
    );

    match Object::parse(&buffer) {
        Ok(Object::Elf(elf)) => {
            println!("{}", "┌── [ĐỊNH DẠNG: LINUX ELF BINARY]".bright_green());
            println!(
                "│ • Kiến trúc    : {}-bit | Little Endian: {} | Entry Point: 0x{:X}",
                if elf.is_64 { 64 } else { 32 },
                elf.little_endian,
                elf.entry
            );
            println!(
                "│ • Thư viện động: {:?} ({} thư viện)",
                elf.libraries,
                elf.libraries.len()
            );
            println!("├── [DANH SÁCH SECTIONS TIÊU BIỂU & ĐỘ NÉN ENTROPY]".bright_green());
            for sh in elf.section_headers.iter().take(10) {
                let name = elf.shdr_strtab.get_at(sh.sh_name).unwrap_or("<unknown>");
                let start = sh.sh_offset as usize;
                let end = (start + sh.sh_size as usize).min(buffer.len());
                let sec_entropy = if start < end {
                    calculate_entropy(&buffer[start..end])
                } else {
                    0.0
                };
                println!(
                    "│   • {:<16} | Offset: 0x{:06X} | Size: {:>8} B | Entropy: {:.2}",
                    name.yellow(),
                    sh.sh_offset,
                    sh.sh_size,
                    sec_entropy
                );
            }
            println!(
                "└── [SYMBOLS] Dynamic Symbols: {} | Normal Symbols: {}",
                elf.dynsyms.len(),
                elf.syms.len()
            );
        }
        Ok(Object::PE(pe)) => {
            println!("{}", "┌── [ĐỊNH DẠNG: WINDOWS PORTABLE EXECUTABLE (PE)]".bright_green());
            println!(
                "│ • Kiến trúc    : {}-bit | DLL: {} | Entry Point: 0x{:X}",
                if pe.is_64 { 64 } else { 32 },
                pe.is_lib,
                pe.entry
            );
            println!("│ • DLL Imports  : {:?}", pe.libraries);
            println!("└── • Số lượng Sections: {} | Exports: {}", pe.sections.len(), pe.exports.len());
        }
        Ok(Object::Mach(mach)) => {
            println!("{} Phát hiện file macOS/iOS Mach-O Binary ({:?})", "[+]".bright_green(), mach);
        }
        Ok(_) => println!("{}", "[*] Định dạng archive/khác.".yellow()),
        Err(e) => println!("{} Không phải file ELF/PE/Mach-O chuẩn: {}", "[!]".red(), e),
    }
}
