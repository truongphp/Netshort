use colored::*;
use std::time::Instant;

/// Hàm băm 64-bit FNV-1a kết hợp Xorshift64* chạy ở tốc độ CPU gốc (Zero-allocation).
/// Được gắn `#[no_mangle]` và `pub extern "C"` để có thể biên dịch thẳng ra file `.wasm`
/// và gọi trực tiếp từ JavaScript / Cloudflare Workers / Browser.
#[no_mangle]
pub extern "C" fn wasm_fast_hash_stream(seed: u64, rounds: u32) -> u64 {
    let mut hash: u64 = 0xcbf29ce484222325 ^ seed;
    let mut state: u64 = seed.wrapping_add(0x9e3779b97f4a7c15);

    for _ in 0..rounds {
        // Xorshift64* PRNG step
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        let val = state.wrapping_mul(0x2545F4914F6CDD1D);

        // FNV-1a 64-bit mixing
        for b in val.to_le_bytes() {
            hash ^= b as u64;
            hash = hash.wrapping_mul(0x100000001b3);
        }
    }
    hash
}

/// Mã hóa / Giải mã dòng byte bằng khóa dòng Xorshift64* (Stream XOR in-place)
pub fn stream_xor_transform(data: &mut [u8], key: u64) {
    let mut state = if key == 0 { 0xCAFEBABE1337BEEF } else { key };
    for chunk in data.chunks_mut(8) {
        state ^= state >> 12;
        state ^= state << 25;
        state ^= state >> 27;
        let mask = state.wrapping_mul(0x2545F4914F6CDD1D).to_le_bytes();
        for (b, m) in chunk.iter_mut().zip(mask.iter()) {
            *b ^= *m;
        }
    }
}

pub fn run_cli_benchmark() {
    println!("{}", "--- MODULE 3: WASM-READY HIGH-SPEED COMPUTE & STREAM ENGINE ---".bold().bright_green());

    let rounds: u32 = 10_000_000;
    println!(
        "{} Đang chạy {} vòng băm 64-bit FNV-1a + Xorshift64* (Zero-Allocation)...",
        "[*]".cyan(),
        rounds
    );

    let start = Instant::now();
    let digest = wasm_fast_hash_stream(0x1337_C0DE, rounds);
    let elapsed = start.elapsed();

    let mops = (rounds as f64) / elapsed.as_secs_f64() / 1_000_000.0;
    println!(
        "{} Hoàn tất trong: {:?} | Tốc độ: {:.2} Triệu vòng/giây | Digest: 0x{:016X}",
        "[+]".bright_green(),
        elapsed,
        mops,
        digest
    );

    // Demo Stream XOR Transform
    let secret_msg = "Rust Core Lab // Low-Level Speed Test!";
    let mut buf = secret_msg.as_bytes().to_vec();
    stream_xor_transform(&mut buf, 0x9988776655443322);
    let hex_cipher: String = buf.iter().map(|b| format!("{:02x}", b)).collect();
    stream_xor_transform(&mut buf, 0x9988776655443322);
    let recovered = String::from_utf8_lossy(&buf);

    println!("\n{}", "┌── [KIỂM THỬ STREAM XOR IN-PLACE]".bright_green());
    println!("│ • Bản rõ gốc    : {}", secret_msg.white());
    println!("│ • Bản mã (Hex)  : {}", hex_cipher.yellow());
    println!("└── • Giải mã ngược : {}", recovered.bright_green().bold());

    println!("\n{}", "[MẸO BIÊN DỊCH RA WEBASSEMBLY (.WASM) TRÊN CODESPACES]".bright_cyan());
    println!("  1. Cài target: rustup target add wasm32-unknown-unknown");
    println!("  2. Build Wasm: cargo build --release --lib --target wasm32-unknown-unknown");
}
