use colored::*;
use std::io::{self, Write};

/// Gói tin mẫu: IPv4 (20B) + TCP (20B, SYN/PSH/ACK) + TLS 1.2 ClientHello (chứa SNI: api.nextdns.io)
const SAMPLE_TLS_PACKET_HEX: &str = concat!(
    "450000601c4640004006b1e2c0a8010a6810f8f9", // IPv4: 192.168.1.10 -> 104.16.248.249
    "d43101bb00000001000000015018faf09a7b0000", // TCP: 54321 -> 443 (PSH, ACK)
    "16030100330100002f0303",                   // TLS Record (Handshake) + ClientHello (TLS 1.2)
    "524e4730313233343536373839616263",         // Client Random (16B đầu)
    "6465666768696a6b6c6d6e6f70717273",         // Client Random (16B sau)
    "00000213010100",                           // SessionID(0) + CipherSuite(TLS_AES_128_GCM_SHA256) + Comp
    "0014",                                     // Extensions Total Length (20 bytes)
    "00000010000e00000b6170692e6e657874646e732e696f" // Extension server_name: "api.nextdns.io"
);

#[derive(Debug)]
pub struct Ipv4HeaderView<'a> {
    pub raw: &'a [u8],
    pub version: u8,
    pub ihl_bytes: usize,
    pub total_len: u16,
    pub ttl: u8,
    pub protocol: u8,
    pub src_ip: [u8; 4],
    pub dst_ip: [u8; 4],
}

impl<'a> Ipv4HeaderView<'a> {
    pub fn parse(data: &'a [u8]) -> Result<Self, &'static str> {
        if data.len() < 20 {
            return Err("Gói tin nhỏ hơn kích thước tối thiểu của IPv4 Header (20 bytes)");
        }
        let version = data[0] >> 4;
        let ihl_bytes = ((data[0] & 0x0F) as usize) * 4;
        if version != 4 || ihl_bytes < 20 || data.len() < ihl_bytes {
            return Err("IPv4 Header không hợp lệ hoặc độ dài IHL vượt quá gói tin");
        }
        Ok(Self {
            raw: &data[..ihl_bytes],
            version,
            ihl_bytes,
            total_len: u16::from_be_bytes([data[2], data[3]]),
            ttl: data[8],
            protocol: data[9],
            src_ip: [data[12], data[13], data[14], data[15]],
            dst_ip: [data[16], data[17], data[18], data[19]],
        })
    }
}

#[derive(Debug)]
pub struct TcpHeaderView<'a> {
    pub src_port: u16,
    pub dst_port: u16,
    pub seq_num: u32,
    pub ack_num: u32,
    pub header_len: usize,
    pub flags: u8,
    pub window_size: u16,
    pub payload: &'a [u8],
}

impl<'a> TcpHeaderView<'a> {
    pub fn parse(segment: &'a [u8]) -> Result<Self, &'static str> {
        if segment.len() < 20 {
            return Err("TCP Segment nhỏ hơn 20 bytes");
        }
        let header_len = (((segment[12] >> 4) & 0x0F) as usize) * 4;
        if header_len < 20 || segment.len() < header_len {
            return Err("TCP Data Offset không hợp lệ");
        }
        Ok(Self {
            src_port: u16::from_be_bytes([segment[0], segment[1]]),
            dst_port: u16::from_be_bytes([segment[2], segment[3]]),
            seq_num: u32::from_be_bytes([segment[4], segment[5], segment[6], segment[7]]),
            ack_num: u32::from_be_bytes([segment[8], segment[9], segment[10], segment[11]]),
            header_len,
            flags: segment[13],
            window_size: u16::from_be_bytes([segment[14], segment[15]]),
            payload: &segment[header_len..],
        })
    }

    pub fn format_flags(&self) -> String {
        let mut list = Vec::new();
        if self.flags & 0x01 != 0 { list.push("FIN"); }
        if self.flags & 0x02 != 0 { list.push("SYN"); }
        if self.flags & 0x04 != 0 { list.push("RST"); }
        if self.flags & 0x08 != 0 { list.push("PSH"); }
        if self.flags & 0x10 != 0 { list.push("ACK"); }
        if self.flags & 0x20 != 0 { list.push("URG"); }
        if list.is_empty() { "NONE".into() } else { list.join(" | ") }
    }
}

/// Bóc tách zero-copy trường Server Name Indication (SNI) từ TLS ClientHello payload
pub fn dissect_tls_sni(payload: &[u8]) -> Option<(&str, u16)> {
    // TLS Record Header: Type 0x16 (Handshake), Version (2B), Length (2B)
    if payload.len() < 43 || payload[0] != 0x16 || payload[5] != 0x01 {
        return None;
    }
    let tls_version = u16::from_be_bytes([payload[9], payload[10]]);
    let mut cursor = 5 + 4 + 2 + 32; // Record(5) + Handshake(4) + ClientVersion(2) + Random(32)
    if cursor >= payload.len() {
        return None;
    }

    // Bỏ qua Session ID
    let sid_len = payload[cursor] as usize;
    cursor += 1 + sid_len;
    if cursor + 2 > payload.len() {
        return None;
    }

    // Bỏ qua Cipher Suites
    let suites_len = u16::from_be_bytes([payload[cursor], payload[cursor + 1]]) as usize;
    cursor += 2 + suites_len;
    if cursor >= payload.len() {
        return None;
    }

    // Bỏ qua Compression Methods
    let comp_len = payload[cursor] as usize;
    cursor += 1 + comp_len;
    if cursor + 2 > payload.len() {
        return None;
    }

    // Duyệt danh sách TLS Extensions
    let ext_total = u16::from_be_bytes([payload[cursor], payload[cursor + 1]]) as usize;
    cursor += 2;
    let end = (cursor + ext_total).min(payload.len());

    while cursor + 4 <= end {
        let ext_type = u16::from_be_bytes([payload[cursor], payload[cursor + 1]]);
        let ext_len = u16::from_be_bytes([payload[cursor + 2], payload[cursor + 3]]) as usize;
        cursor += 4;

        // Extension 0x0000 = server_name
        if ext_type == 0x0000 && cursor + 5 <= end {
            let name_type = payload[cursor + 2];
            let name_len = u16::from_be_bytes([payload[cursor + 3], payload[cursor + 4]]) as usize;
            if name_type == 0x00 && cursor + 5 + name_len <= end {
                let sni_slice = &payload[cursor + 5..cursor + 5 + name_len];
                if let Ok(hostname) = std::str::from_utf8(sni_slice) {
                    return Some((hostname, tls_version));
                }
            }
        }
        cursor += ext_len;
    }
    None
}

fn decode_hex(input: &str) -> Result<Vec<u8>, String> {
    let filtered: String = input.chars().filter(|c| !c.is_whitespace()).collect();
    if filtered.len() % 2 != 0 {
        return Err("Chuỗi Hex phải có số ký tự chẵn.".into());
    }
    (0..filtered.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&filtered[i..i + 2], 16).map_err(|e| e.to_string()))
        .collect()
}

pub fn run() {
    println!("{}", "--- MODULE 1: ZERO-COPY PACKET & TLS SNI DISSECTOR ---".bold().bright_green());
    print!("{}", "Nhập chuỗi Hex gói tin IPv4/TCP (Enter để phân tích gói TLS mẫu): ".cyan());
    let _ = io::stdout().flush();

    let mut raw_in = String::new();
    let _ = io::stdin().read_line(&mut raw_in);
    let hex_target = if raw_in.trim().is_empty() {
        SAMPLE_TLS_PACKET_HEX
    } else {
        raw_in.trim()
    };

    let packet = match decode_hex(hex_target) {
        Ok(b) => b,
        Err(e) => {
            println!("{} {}", "[!] Lỗi giải mã Hex:".red(), e);
            return;
        }
    };

    let ipv4 = match Ipv4HeaderView::parse(&packet) {
        Ok(hdr) => hdr,
        Err(e) => {
            println!("{} {}", "[!] Lỗi tầng IPv4:".red(), e);
            return;
        }
    };

    println!("\n{}", "┌── [LAYER 3: IPv4 HEADER]".bright_green());
    println!(
        "│ • Nguồn ➔ Đích : {}.{}.{}.{} ➔ {}.{}.{}.{}",
        ipv4.src_ip[0], ipv4.src_ip[1], ipv4.src_ip[2], ipv4.src_ip[3],
        ipv4.dst_ip[0], ipv4.dst_ip[1], ipv4.dst_ip[2], ipv4.dst_ip[3]
    );
    println!(
        "│ • Header Length : {} bytes | Total Len: {} bytes | TTL: {} | Proto: 0x{:02X}",
        ipv4.ihl_bytes, ipv4.total_len, ipv4.ttl, ipv4.protocol
    );

    if ipv4.protocol != 6 {
        println!("{}", "└── [!] Gói tin không phải giao thức TCP (Proto != 6).".yellow());
        return;
    }

    let tcp = match TcpHeaderView::parse(&packet[ipv4.ihl_bytes..]) {
        Ok(seg) => seg,
        Err(e) => {
            println!("{} {}", "└── [!] Lỗi tầng TCP:".red(), e);
            return;
        }
    };

    println!("{}", "├── [LAYER 4: TCP SEGMENT]".bright_green());
    println!(
        "│ • Cổng kết nối : {} ➔ {} | Cờ (Flags): [{}]",
        tcp.src_port.to_string().yellow(),
        tcp.dst_port.to_string().yellow(),
        tcp.format_flags().bright_cyan()
    );
    println!(
        "│ • Seq / Ack    : Seq={} | Ack={} | Window={}",
        tcp.seq_num, tcp.ack_num, tcp.window_size
    );

    println!("{}", "└── [LAYER 7: PAYLOAD & TLS SNI INSPECTION]".bright_green());
    if let Some((sni, ver)) = dissect_tls_sni(tcp.payload) {
        println!(
            "    • Giao thức  : TLS Handshake ClientHello (Version: 0x{:04X})",
            ver
        );
        println!(
            "    • {} : {}",
            "SNI Domain".bold().bright_yellow(),
            sni.bold().bright_white().on_green()
        );
    } else {
        println!(
            "    • Payload thô: {} bytes (Không chứa cấu trúc TLS ClientHello SNI)",
            tcp.payload.len()
        );
    }
}
