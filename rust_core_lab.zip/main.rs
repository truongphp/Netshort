mod binary_inspector;
mod packet_parser;
mod wasm_engine;

use colored::*;
use std::io::{self, Write};

const BANNER: &str = r#"
 ____            _      ____                 _          _     
|  _ \ _   _ ___| |_   / ___|___  _ __ ___  | |    __ _| |__  
| |_) | | | / __| __| | |   / _ \| '__/ _ \ | |   / _` | '_ \ 
|  _ <| |_| \__ \ |_  | |__| (_) | | |  __/ | |__| (_| | |_) |
|_| \_\\__,_|___/\__|  \____\___/|_|  \___| |_____\__,_|_.__/ 
"#;

fn prompt(msg: &str) -> String {
    print!("{}", msg);
    let _ = io::stdout().flush();
    let mut buf = String::new();
    let _ = io::stdin().read_line(&mut buf);
    buf.trim().to_string()
}

fn main() {
    loop {
        println!("{}", BANNER.bright_green().bold());
        println!(
            "{}",
            "  [SYSTEMS & NETWORK ENGINEERING SUITE // ZERO-COPY & WASM READY]"
                .bright_cyan()
        );
        println!("{}", "==================================================================".green());
        println!(
            "  {} {} — Bóc tách từng bit IPv4, TCP Flags & TLS ClientHello SNI",
            "[1]".bold().yellow(),
            "Zero-Copy Packet & TLS SNI Dissector".bold().white()
        );
        println!(
            "  {} {} — Phân tích cấu trúc file thực thi (ELF / PE / Mach-O)",
            "[2]".bold().yellow(),
            "Executable Format & Section Analyzer".bold().white()
        );
        println!(
            "  {} {} — Đua tốc độ tính toán & băm FNV-1a/XOR (Native + Wasm)",
            "[3]".bold().yellow(),
            "Wasm-Ready High-Speed Compute Engine".bold().white()
        );
        println!(
            "  {} {}",
            "[0]".bold().red(),
            "Thoát chương trình".dimmed()
        );
        println!("{}", "==================================================================".green());

        let choice = prompt("\n⚡ Chọn module [0-3]: ");
        println!();

        match choice.as_str() {
            "1" => packet_parser::run(),
            "2" => binary_inspector::run(),
            "3" => wasm_engine::run_cli_benchmark(),
            "0" => {
                println!("{}", "[+] Đã đóng Rust Core Lab. Hẹn gặp lại bro!".bright_green());
                break;
            }
            _ => println!("{}", "[!] Lựa chọn không hợp lệ, vui lòng nhập từ 0 đến 3.".red()),
        }

        let _ = prompt("\n[Nhấn Enter để quay lại bảng điều khiển...]");
    }
}
